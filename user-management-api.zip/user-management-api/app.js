const express = require('express');
const mysql = require('mysql2');
const Joi = require('joi');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');

const app = express();
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'api_user',
  password: 'api123',
  database: 'user_management'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

const userSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^[0-9]{10,}$/).required(),
  is_active: Joi.boolean().required(),
  department: Joi.string().required()
});

app.post('/api/users', (req, res) => {
  const { error } = userSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const { name, email, phone, is_active, department } = req.body;
  const sql = 'INSERT INTO users (name, email, phone, is_active, department) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, email, phone, is_active, department], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ id: result.insertId, ...req.body });
  });
});

app.get('/api/users', (req, res) => {
  db.query('SELECT * FROM users', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

app.put('/api/users/:id', (req, res) => {
  const { error } = userSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const { name, email, phone, is_active, department } = req.body;
  const sql = 'UPDATE users SET name=?, email=?, phone=?, is_active=?, department=? WHERE id=?';
  db.query(sql, [name, email, phone, is_active, department, req.params.id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: req.params.id, ...req.body });
  });
});

app.delete('/api/users/:id', (req, res) => {
  db.query('DELETE FROM users WHERE id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'User deleted' });
  });
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});