CREATE DATABASE IF NOT EXISTS user_management;

USE user_management;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(15) NOT NULL,
  is_active BOOLEAN NOT NULL,
  department VARCHAR(100) NOT NULL
);

INSERT INTO users (name, email, phone, is_active, department) VALUES
('Budi Santoso', 'budi@example.com', '0812345678', TRUE, 'IT'),
('Siti Aminah', 'siti@example.com', '0823456789', TRUE, 'Finance'),
('Ahmad Fauzi', 'ahmad@example.com', '0834567890', FALSE, 'HR'),
('Dewi Lestari', 'dewi@example.com', '0845678901', TRUE, 'Marketing');